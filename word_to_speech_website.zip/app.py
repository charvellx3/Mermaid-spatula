import os
import boto3
from flask import Flask, render_template, request, send_file, redirect, url_for
from werkzeug.utils import secure_filename
from docx import Document

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['AUDIO_FOLDER'] = 'static/audio'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['AUDIO_FOLDER'], exist_ok=True)

# Initialize Polly
polly = boto3.client(
    'polly',
    region_name='us-east-1',
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY")
)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        voice_id = request.form['voice']
        file = request.files['file']
        if file and file.filename.endswith('.docx'):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Extract text from the docx file
            document = Document(filepath)
            full_text = ' '.join([para.text for para in document.paragraphs])

            # Convert text to speech using Polly
            response = polly.synthesize_speech(
                Text=full_text,
                OutputFormat='mp3',
                VoiceId=voice_id
            )

            audio_filename = f"{os.path.splitext(filename)[0]}.mp3"
            audio_path = os.path.join(app.config['AUDIO_FOLDER'], audio_filename)

            with open(audio_path, 'wb') as f:
                f.write(response['AudioStream'].read())

            return redirect(url_for('download_file', filename=audio_filename))
    return render_template('index.html')

@app.route('/download/<filename>')
def download_file(filename):
    path = os.path.join(app.config['AUDIO_FOLDER'], filename)
    return send_file(path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
